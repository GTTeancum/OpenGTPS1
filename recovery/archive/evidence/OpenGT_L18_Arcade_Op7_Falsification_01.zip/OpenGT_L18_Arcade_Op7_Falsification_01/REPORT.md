# OpenGT L18 — Arcade Op-7 Falsification Probe 01

**Date:** September 24, 2026  
**Checkpoint:** exact L18 managed runtime/host, diagnostic hooks only  
**Purpose:** determine whether GT2 naturally invokes async op 7 when live Arcade save state is meaningfully changed before the Save Game flow.

## Setup

This probe used the already-proven seeded Arcade overwrite route and valid 4-block diagnostic card:

- seed card SHA-256: `f747c31342346f76cfc242bc930c2adf867c48746f8607437d7bdc74459f8ba5`
- native Save Game UI path: selection 3 -> existing-save classify -> overwrite confirmation -> state 7 -> state 8 -> clean exit
- compatibility save bridge: **disabled/unset**
- early QA-only Arcade progress mutation: **enabled**
- payload-builder trace: **enabled**
- low-level GT2 card-op trace: **enabled**

The QA mutation was moved from poll 820 to poll 1 specifically to test whether a meaningfully dirty live Arcade state would cause the original GT2 Save Game path to serialize and/or issue op 7 naturally.

## Result

The live working state definitely changed before the Save Game transaction:

`[GT2] arcade test-progress patch active: course0=0x04`

Runtime save telemetry later confirmed:

`arcadeDifficult=1/21 arcade=[0x04,0x00,...]`

However:

1. **`func_8006A124` never executed.**  
   No `[GT2-PayloadBuild]` line appeared anywhere in the run, despite `RECOMPONE_TRACE_GT2_PAYLOAD_BUILD=1`.

2. **Only async operation 6 executed.**  
   The complete operation trace contained exactly:
   - startup/load: `caller=0x8006A110 op=6 ... buffer=0x800A8B08 len=0x7F00`
   - Save Game state 7: `caller=0x8006A110 op=6 ... buffer=0x800BF524 len=0x7F00`

3. **Async operation 7 never appeared.**

4. **The backing card did not change.**  
   Final card-A SHA-256 remained the seed identity:

   `f747c31342346f76cfc242bc930c2adf867c48746f8607437d7bdc74459f8ba5`

   `inotifywait` showed no post-startup `MODIFY/CLOSE_WRITE` on card A.

5. The native UI/state transaction still completed normally:
   - state 3 -> event 6
   - state 6 -> event 7
   - state 7 -> event 8
   - state 8 -> event 10

## Interpretation

This falsifies the working hypothesis that **op 7 is naturally selected by this Save Game flow merely when live Arcade state is dirty**.

The changed live working byte never entered the 0x8000-byte save payload because the Save Game path did not call GT2's serializer `0x8006A124`. The path still performed op 6, which prior static/runtime evidence definitively identifies as the read/load/verify transaction.

Therefore, for this retained L18/recomposed Arcade Save Game flow:

- op 6 is the only native card transaction exercised by Save Game state 7;
- op 7 is not a delayed or dirty-state-dependent continuation of this flow;
- the original state machine reports successful completion without reaching RecompOne persistent card storage;
- the previously proven **snapshot-on-submit / commit-after-native-success compatibility bridge** is justified as a compatibility layer at the Save Game semantic boundary rather than waiting for a native op-7 transition that does not occur here.

### Important limit

This test uses a QA-only direct working-memory mutation. It proves that dirty live state alone does not make this Save Game route invoke op 7 or its serializer. It does **not** claim that op 7 is unused elsewhere in GT2.

## Production direction

The production candidate should preserve:

1. GT2's existing Save Game UI and native success/failure state machine;
2. GT2-generated payload/CRC bytes when they are available;
3. snapshot-before-op6-clobber semantics;
4. persistence commit only after native state-7 async success;
5. no QA-only progress mutation, forced payload refresh, or verbose trace hooks by default.

A final ordinary-state regression is still required before enabling the bridge by default: create a legitimate in-game Arcade state change through normal gameplay/UI, save it with the candidate bridge, and verify clean restart/reload without any QA mutation hook.
