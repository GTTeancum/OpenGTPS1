# OpenGT L18 — Arcade Persistence Closure 01

**Date:** September 24, 2026  
**Checkpoint:** exact L18 Linux runtime + diagnostic compatibility bridge candidate  
**Scope:** prove a meaningful GT2 Arcade save mutation is written to the backing card and reloads in a clean process

## Result

**End-to-end Arcade memory-card persistence is proven under the HLE save-bridge candidate.**

The final proof preserves GT2's native Save Game UI and state machine. The compatibility bridge snapshots GT2's CRC-valid outgoing payload when native write state 7 submits the async operation, then commits that exact snapshot to RecompOne's persistent `MemoryCard` only after GT2 reports the async operation succeeded.

This is necessary because the original L18 low-level GT2 async memory-card driver reaches native write state 7 and reports event 8 (success), but never enters RecompOne's BIOS A/B card APIs, `FrameWrite`, or `MemoryCard.Flush`; the low-level SIO-style path is not bridged to persistent storage.

## Meaningful mutation used for QA

A test-only Arcade progress hook set the legitimate live Arcade course-result byte at guest `0x801C93F8` from `0x00` to `0x04`. This address lies inside the game's serialized Arcade working block.

Because the QA mutation occurs later than GT2's normal payload-build timing, a **test-only payload refresh** invoked GT2's own serializer `0x8006A124` immediately before native write submission. This refresh is not part of the production bridge candidate.

Before refresh:

- live working byte: `0x04`
- payload byte at save offset `0x2B8`: `0x00`
- payload CRC field: `0x00000000`

After GT2's own `0x8006A124` refresh:

- live working byte: `0x04`
- payload byte at save offset `0x2B8`: `0x04`
- GT2 CRC: `0xB9CA1C8C`

## Snapshot/commit bridge

The first HLE bridge attempt read the guest payload only after async completion. That was incorrect because GT2's low-level async layer had replaced/clobbered the write buffer with the previously loaded seed contents by then.

The corrected bridge behavior is:

1. **Capture at native write submission**
   - read the outgoing GT2 payload,
   - require an existing `BASCUS-94455GAME`,
   - validate stored CRC against `Gt2SaveCrc32`,
   - retain the exact validated bytes in a pending per-slot snapshot.
2. Allow GT2's native async state machine to run unchanged.
3. **Commit only after native async success**
   - state 7 reaches the existing successful completion path,
   - write the captured payload into the existing four-block memory-card file,
   - flush backing storage.

Final runtime markers:

- `[GT2-SaveBridge] captured ... crc=0xB9CA1C8C`
- native state 7 / `0x800247D0`
- `[GT2-SaveBridge] completed ... crc=0xB9CA1C8C`
- native event 8 success

## Card validation

Diagnostic seed card before native overwrite:

- SHA-256: `f747c31342346f76cfc242bc930c2adf867c48746f8607437d7bdc74459f8ba5`
- GT2 CRC: `0x8D5C9132`
- Arcade save byte `0x2B8`: `0x00`

Card after the native Save Game + bridge run:

- SHA-256: `2502605c07a8349c5397431c52aec652f1261a602fad611cac506abd56d30fa2`
- `BASCUS-94455GAME`
- four-block chain: `1,2,3,4`
- logical save length: `0x8000` bytes
- stored GT2 CRC: `0xB9CA1C8C`
- computed GT2 CRC: `0xB9CA1C8C`
- serialized Arcade byte at `0x2B8`: `0x04`

The card changed meaningfully and remained structurally/checksum valid.

## Clean reload proof

A completely new process was started with the newly saved card.

Disabled for the reload run:

- `RECOMPONE_GT2_CREATE_TEST_SAVE`
- `RECOMPONE_GT2_ARCADE_TEST_PROGRESS`
- `RECOMPONE_GT2_ARCADE_SAVE_BRIDGE`
- card-bridge tracing

The clean runtime reported:

`[GT2-Save] ... arcadeDifficult=1/21 arcade=[0x04,0x00,...]`

The card hash remained:

`2502605c07a8349c5397431c52aec652f1261a602fad611cac506abd56d30fa2`

Therefore the `0x04` state came from the persisted card, not an active QA mutation or save bridge.

## Conclusion

The persistence investigation is closed at the mechanism level:

- native Save Game navigation works,
- GT2 reaches its actual async write state,
- GT2's low-level async layer reports success but does not reach RecompOne persistent card APIs,
- snapshot-on-submit / commit-on-success bridges that missing persistence layer,
- a meaningful GT2-generated save mutation is physically written with a valid CRC,
- the saved mutation reloads in a clean process with all QA mutation/bridge flags disabled.

### Productionization boundary

The **production candidate** is only the semantic save bridge (capture CRC-valid outgoing payload at submission; commit after native async success).

The following must remain QA/diagnostic-only and must not be promoted as gameplay behavior:

- `RECOMPONE_GT2_ARCADE_TEST_PROGRESS`
- state-7 payload refresh used to serialize the deliberately late QA mutation
- verbose save/card trace hooks

Before enabling the bridge by default, run a focused save regression using ordinary game state that was changed before entering Save Game, so GT2's normal payload-build timing supplies the outgoing payload without the QA refresh hook.

## Post-proof semantic caution: operation 6 vs operation 7

After the successful write/reload proof, further exact-L18 static review found paired GT2 async wrappers:

- `func_8006A0C4` queues operation code **6** through `func_8007D568`.
- `func_8006A064` queues operation code **7** through the same driver.
- the observed Save Game state-7 path calls operation **6**.

During operation 6, the in-memory payload buffer is replaced with the previously loaded card payload before completion. That behavior is consistent with a **read/verify** semantic and means it is premature to call operation 6 the canonical physical-write primitive merely because it occurs inside the Save Game state machine.

The snapshot/commit bridge still proves the important end-to-end facts:

- RecompOne can persist a GT2-generated, CRC-valid 4-block save,
- that save survives a clean process restart,
- the serialized gameplay byte reloads correctly,
- the low-level GT2 async path does not itself reach persistent `MemoryCard` storage in L18.

However, **production placement of the compatibility bridge is not finalized yet**. Before enabling it by default, trace `func_8007D568` operation codes/callers during the complete Save Game flow and determine whether operation 7 is the intended write primitive or whether another higher-level transition is absent. The production fix should attach to the correct semantic write boundary; the current operation-6 snapshot bridge remains an opt-in compatibility candidate / QA proof.
