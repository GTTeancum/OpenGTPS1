# OpenGTPS1 Lighting L18 — world-geometry-stable exact unbake audit candidate

Verified September 23, 2026. Cumulative over L17. This is a non-destructive
source/runtime-evidence checkpoint. It does **not** enable baked-light removal and
it is not a fresh gameplay validation.

## Result

L17 made destructive material rules content-bound end to end, while the L16/L15
audit required exact provenance, temporal persistence and cross-view evidence.
One remaining weakness was that a source identity could stay stable while its
reconstructed receiver geometry moved or rotated in world space. That would make
it unsafe to interpret dark-vs-bright authored color as a fixed baked shadow on a
stationary course surface.

L18 records camera-independent reconstructed world geometry for each conservative
audit primitive and accumulates three scale-normalized stability metrics across
every distinct observed frame:

- maximum centroid drift divided by triangle edge scale,
- maximum receiver-plane offset divided by triangle edge scale, and
- maximum receiver-plane normal-angle change.

The offline analyzer is now format v4. A record is eligible for candidate grouping
only when all prior L16/L17 requirements pass **and** the world-geometry evidence
is present and remains within conservative audit-only bounds: centroid drift <=
0.10 edge lengths, plane offset <= 0.05 edge lengths, and plane-angle change <=
5 degrees. Missing geometry metrics are treated as ineligible, so older logs remain
readable but cannot silently satisfy the new gate.

The runtime audit remains observational. These metrics do not feed shader constants,
materials, shadow casters, draw lists or destructive material matching. No existing
Seattle/Red Rock rule was added or changed, and the analyzer still reports
`destructiveRulesGenerated: false`.

## End-to-end proof

The native lighting fixture traverses the real `prepare()` audit path while its
source camera rotates by 90 degrees. Its stationary reconstructed world triangle
reports zero centroid drift, zero plane offset and zero plane-angle drift through
stage 0 -> stage 1 -> stage 2. The v4 analyzer accepts that identity's geometry
stability while its synthetic regression rejects otherwise-identical records with
0.25 edge centroid drift, 0.12 edge plane offset and 12 degrees of plane rotation.

Invalid/NaN and degenerate reconstructed world triangles are rejected before they
can enter the audit.

## Validation

The exact final source passes:

- **1,195 focused lighting checks** in Release.
- **1,195 focused lighting checks** under Clang 17 ASan/UBSan with leak detection
  and halt-on-error enabled.
- **18/18 native suites in Release**.
- **18/18 native suites under Clang 17 ASan/UBSan**.
- EGL pixel tests and shadow-visibility tests in both matrices.
- Analyzer v4 self-test, including temporal, content, cross-view, authored-color
  ambiguity, geometry-instability, legacy-log and truncation cases.

The sanitizer run reused the already validated L17 Clang ASan/UBSan build tree to
avoid recompiling unchanged large topology units. The four L18 source files were
copied into that exact L17 source tree, all dependent targets were rebuilt/relinked,
and all 400 source files were then hash-compared against the packaged L18 source;
`validation/sanitizer-source-equivalence.json` reports zero differences.

The approved lighting preset remains byte-for-byte unchanged:

```
29e55120508bb0540bf29ab633b4177c0f77bdb546c6b89bacfa390bcbd4cf6e  lighting/in-game-L05.shader
```

## Reconstruction and package integrity

Exactly four source files differ from L17:

- `native/include/opengt/lighting.hpp`
- `native/src/lighting.cpp`
- `native/tests/lighting_tests.cpp`
- `tools/analyze_unbake_audit.py`

`overlay/` contains their exact bytes. Applying that binary-safe overlay to the
packaged L17 source reconstructs all **400 source files byte-for-byte**; see
`validation/reconstruction.json`. `L18-from-L17.review.patch` is review-only.

The package contains source, exact overlay, review diff and validation evidence.
It does not contain GT2 game data, saves, the original split OpenGT upload, .NET
SDK/NuGet inputs, or compiled game/native binaries.

## Remaining boundary

Fresh Seattle daytime and Red Rock dusk/camera-switch execution still cannot be
performed in this runtime because the exact original GT2/prepared host inputs are
not available. **L08 remains the last actual gameplay-validated checkpoint.**

L18 is intentionally the end of the useful source-only audit hardening path. The
next meaningful work is a real L18 audit run on Seattle and Red Rock, followed by
human/source verification of any fully-qualified candidate before authoring even a
single destructive rule.
