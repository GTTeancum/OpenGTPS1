#pragma once

#include <stddef.h>
#include <stdint.h>

#if defined(_WIN32)
#define OPENGT_LIVE_EXPORT __declspec(dllexport)
#else
#define OPENGT_LIVE_EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif

enum {
    OPENGT_LIVE_DEPTH = 1u << 0,
    OPENGT_LIVE_DITHER = 1u << 1,
    OPENGT_LIVE_TOPOLOGY = 1u << 2,
    OPENGT_LIVE_PERSPECTIVE = 1u << 3,
    OPENGT_LIVE_WARP = 1u << 4,
    OPENGT_LIVE_TEXTURE_SMOOTHING = 1u << 5,
    OPENGT_LIVE_REALTIME_READBACK = 1u << 6,
    OPENGT_LIVE_HIGH_RESOLUTION_TEXTURES = 1u << 7,
    // The caller supplied its D3D11 presentation device and requests a
    // same-device texture result. output_rgba remains a valid fallback
    // buffer, but no GPU-to-CPU staging copy is performed for this frame.
    OPENGT_LIVE_DIRECT_GPU_OUTPUT = 1u << 8,
};

typedef struct opengt_live_options {
    uint32_t struct_size;
    uint32_t flags;
    uint32_t output_scale;
    uint32_t clear_color_rgba8;
    // Horizontal-plus output aspect. A zero component preserves the guest
    // display width. The vertical resolution and field of view never change.
    uint32_t target_aspect_width;
    uint32_t target_aspect_height;
    // Stable caller-owned output slot. A slot is not submitted again until
    // the caller has finished copying the texture returned in stats.
    uint32_t direct_output_slot;
} opengt_live_options;

typedef struct opengt_live_stats {
    uint32_t struct_size;
    uint32_t result;
    uint32_t capture_triangles;
    uint32_t output_commands;
    uint32_t draw_calls;
    uint32_t transparent_draw_calls;
    uint32_t topology_boundary_groups;
    uint32_t topology_t_junctions;
    uint32_t topology_split_triangles;
    uint32_t topology_coplanar_pairs;
    uint32_t topology_ownership_reorders;
    uint32_t output_width;
    uint32_t output_height;
    // CPU elapsed time inside the selected native GPU backend. The synchronous API waits
    // through completion/readback; live asynchronous submissions do not.
    uint64_t render_microseconds;
    uint64_t frame_index;
    int32_t input_poll;
    uint32_t reserved;
    uint64_t decode_microseconds;
    uint64_t draw_list_microseconds;
    uint64_t topology_microseconds;
    uint64_t pipeline_microseconds;
    // Development audit only. Zero unless
    // RECOMPONE_AUDIT_NATIVE_WORLD_OUTPUT_HASH=1; otherwise FNV-1a over the
    // exact tightly-packed RGBA output associated with this authored frame.
    uint64_t output_fingerprint;
    // Ordered semantic fingerprint of the final post-topology world draw
    // list. Unlike output_fingerprint this is produced before asynchronous
    // GPU staging, so it remains intrinsically tied to frame_index/input_poll.
    uint64_t world_fingerprint;
    // Borrowed ID3D11Texture2D*. It remains valid until the caller reuses
    // direct_output_slot in a later render call. Zero selects CPU pixels.
    uint64_t output_texture;
} opengt_live_stats;

enum {
    // No pixel buffer was produced by this real-time submission yet.  The
    // asynchronous readback queue retains the authored frame and publishes it
    // later with the matching metadata.
    OPENGT_LIVE_STATS_NO_OUTPUT = 1u << 3,
};

#if defined(OPENGT_SYNTHETIC_FRAME_DEV_SUPPORT)
typedef struct opengt_live_interpolation_stats {
    uint32_t struct_size;
    uint32_t result;
    uint32_t output_count;
    uint32_t previous_commands;
    uint32_t current_commands;
    uint32_t eligible_world_commands;
    uint32_t matched_commands;
    uint32_t matched_track_commands;
    uint32_t matched_vehicle_commands;
    uint32_t held_screen_commands;
    uint32_t held_unmatched_commands;
    uint32_t previous_transform_groups;
    uint32_t current_transform_groups;
    uint32_t matched_transform_groups;
    uint32_t temporal_reset;
    // Bit 0 records that the midpoint reused exactly compatible prior-frame
    // VRAM/material uploads. Bit 1 records that the current authored draw
    // list contained track commands, so performance telemetry can exclude
    // menus and Results screens from its aligned track-world window.
    uint32_t reserved;
    uint32_t exact_rigid_transform_groups;
    uint32_t incoherent_exact_transform_groups;
    uint32_t held_incoherent_vehicle_commands;
    uint32_t held_track_visibility_commands;
    uint32_t held_unsafe_track_commands;
    uint64_t interpolation_microseconds;
    uint64_t pair_pipeline_microseconds;
    uint64_t midpoint_render_microseconds;
    uint64_t actual_render_microseconds;
    // Topology is built once for the interpolated midpoint. Expose that
    // pair-scoped cost here so live telemetry can keep pipeline, submit, and
    // topology percentile samples aligned.
    uint64_t current_topology_microseconds;
} opengt_live_interpolation_stats;
#endif

typedef struct opengt_live_texture_upload {
    uint64_t key;
    int32_t x;
    int32_t y;
    int32_t word_width;
    int32_t height;
} opengt_live_texture_upload;

OPENGT_LIVE_EXPORT void* opengt_live_create(void);

OPENGT_LIVE_EXPORT void opengt_live_destroy(void* handle);

// Selects the host presentation device for the calling renderer thread.
// Native rendering records on a deferred context and submits one isolated
// command list to this device's immediate context. The device pointer is
// retained until the native renderer thread exits.
OPENGT_LIVE_EXPORT int32_t opengt_live_set_presentation_device(
    void* handle,
    void* d3d11_device);

// With OPENGT_LIVE_REALTIME_READBACK, this submits the authored frame to the
// asynchronous image queue.  stats.reserved carries
// OPENGT_LIVE_STATS_NO_OUTPUT while the initial queue is priming; afterward
// the returned pixels and metadata always identify the same authored frame.
OPENGT_LIVE_EXPORT int32_t opengt_live_render(
    void* handle,
    const uint8_t* capture_bytes,
    size_t capture_size,
    uint8_t* output_rgba,
    size_t output_capacity,
    const opengt_live_options* options,
    opengt_live_stats* stats);

#if defined(OPENGT_SYNTHETIC_FRAME_DEV_SUPPORT)
// Development oracle only: submits one midpoint/actual pair and drains the
// oldest completed pair without
// blocking. output_count is one for an immediate temporal reset, zero when no
// prior pair is ready, and two for a completed chronological pair. Pixel data
// and frame metadata always come from the same staging slots. stats.reserved
// bit 0 marks a synthesized midpoint and bit 2 marks a one-output temporal
// reset boundary that may not be reused as the next 60 Hz native image.
OPENGT_LIVE_EXPORT int32_t opengt_live_render_pair(
    void* handle,
    const uint8_t* capture_bytes,
    size_t capture_size,
    uint8_t* output_first_rgba,
    uint8_t* output_second_rgba,
    size_t output_capacity,
    const opengt_live_options* options,
    opengt_live_stats* first_stats,
    opengt_live_stats* second_stats,
    opengt_live_interpolation_stats* interpolation_stats);

// Drains one additional completed midpoint/actual pair without submitting a
// new authored capture. Returns 1 when a pair was written, 0 when the oldest
// pair is still in flight, and a negative result on error.
OPENGT_LIVE_EXPORT int32_t opengt_live_try_read_pair(
    void* handle,
    uint8_t* output_first_rgba,
    uint8_t* output_second_rgba,
    size_t output_capacity,
    opengt_live_stats* first_stats,
    opengt_live_stats* second_stats);
#endif

OPENGT_LIVE_EXPORT int32_t opengt_live_set_texture_uploads(
    void* handle,
    int32_t software_adapter,
    const opengt_live_texture_upload* uploads,
    size_t upload_count);

// Registers immutable GT2 authored course data. The byte contract is owned by
// the managed raw-track decoder and versioned independently from OGTWCAP.
// Re-registering a key atomically replaces the prior definition, which keeps
// stage/race discontinuities from retaining stale guest RAM contents.
OPENGT_LIVE_EXPORT int32_t opengt_live_register_resident_mesh(
    void* handle,
    const uint8_t* definition_bytes,
    size_t definition_size);

// Selects the exact resident course instances for the next render call. Each
// 96-byte record contains one mesh key plus GT2's exact object-to-view matrix,
// projection state, draw environment, default untextured page, and authored
// capture insertion point. A zero count clears the selection.
OPENGT_LIVE_EXPORT int32_t opengt_live_set_resident_instances(
    void* handle,
    const uint8_t* instance_bytes,
    size_t instance_count);

OPENGT_LIVE_EXPORT uint32_t opengt_live_api_version(void);

#ifdef __cplusplus
}
#endif
