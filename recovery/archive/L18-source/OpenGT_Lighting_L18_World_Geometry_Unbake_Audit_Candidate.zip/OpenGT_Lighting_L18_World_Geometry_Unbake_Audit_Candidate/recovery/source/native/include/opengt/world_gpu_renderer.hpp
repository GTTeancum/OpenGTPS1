#pragma once

#include "opengt/world_draw_list.hpp"

#include <cstddef>
#include <cstdint>

namespace opengt::render {

// The synchronous development path retains four chronological image slots.
// The legacy name remains because development-only midpoint tooling also uses
// the same even ring; the shipping authored-image path does not form pairs.
constexpr std::size_t world_gpu_readback_pair_delay = 2;
// The live authored renderer can queue sixteen immutable image/resource slots
// while earlier GPU copies complete. Development-only pair tooling interprets
// that same capacity as eight pairs; shipping drains individual images in
// chronological order at the authored NTSC VBlank cadence.
constexpr std::size_t world_gpu_async_readback_pair_capacity = 8;
constexpr std::size_t world_gpu_async_readback_image_capacity =
    world_gpu_async_readback_pair_capacity * 2;
constexpr std::size_t world_gpu_direct_output_capacity = 5;
// Live 60 Hz presentation retains four chronological copies. The oldest has
// three submission gaps to retire before it can stop the producer; Seattle's
// densest opening field demonstrated isolated 28--31 ms scheduler tails after
// a three-image queue. The completed-output reserve independently protects CPU
// preparation tails. A future direct GPU presentation path can bypass readback.
constexpr std::size_t world_gpu_realtime_readback_image_delay = 4;
static_assert(
    world_gpu_realtime_readback_image_delay >= 1 &&
    world_gpu_realtime_readback_image_delay <=
        world_gpu_async_readback_image_capacity);

struct WorldGpuRenderOptions {
    bool use_software_adapter;
    bool depth_buffer;
    bool dithering;
    bool perspective_correct;
    bool texture_smoothing;
    bool high_resolution_textures;
    std::uint32_t output_scale;
    std::uint32_t clear_color_rgba8;
    // Retained for callers from the retired pair-rendering path. The live
    // renderer may ignore these hints when distinct in-flight resource slots
    // are required for correctness.
    bool reuse_uploaded_vram = false;
    bool reuse_uploaded_materials = false;
    // Diagnostics only: identifies the generated half-step submitted before
    // an authored current frame. Rendering behavior must not depend on it.
    bool synthetic_midpoint = false;
    // Cadence-gap reset recovery can re-prime the readback ring without
    // forcing the first staged copy to block the worker thread.
    bool defer_initial_readback = false;
    // Submit this image to the live readback queue without synchronously
    // waiting for an older staging resource. Shipping drains complete images
    // in chronological order; the pair API exists only in development builds.
    bool asynchronous_readback = false;
    // Horizontal-plus target aspect. Zero preserves the guest display width.
    // These are deliberately last so existing diagnostic aggregate
    // initializers retain their meaning.
    std::uint32_t target_aspect_width = 0;
    std::uint32_t target_aspect_height = 0;
    // Same-device presentation bypasses staging readback. The selected slot
    // is caller-lifetime-managed and cannot be reused while its texture is
    // still pending presentation.
    bool direct_gpu_output = false;
    std::uint32_t direct_output_slot = 0;
};

inline std::uint32_t world_gpu_target_display_width(
    const WorldDrawList& draw_list,
    const WorldGpuRenderOptions& options
) noexcept {
    if (
        draw_list.display_width <= 0 ||
        draw_list.display_height <= 0 ||
        options.target_aspect_width == 0 ||
        options.target_aspect_height == 0
    ) {
        return draw_list.display_width > 0
            ? static_cast<std::uint32_t>(draw_list.display_width)
            : 0U;
    }
    const std::uint64_t requested =
        (static_cast<std::uint64_t>(draw_list.display_height) *
            options.target_aspect_width +
            options.target_aspect_height - 1U) /
        options.target_aspect_height;
    return requested > static_cast<std::uint32_t>(draw_list.display_width)
        ? static_cast<std::uint32_t>(requested)
        : static_cast<std::uint32_t>(draw_list.display_width);
}

struct WorldGpuRenderStats {
    std::uint32_t commands;
    std::uint32_t draw_calls;
    std::uint32_t transparent_draw_calls;
    std::uint32_t secondary_commands;
    // Commands dropped because their guest drawing area was empty.
    std::uint32_t skipped_empty_scissor_commands;
    bool software_adapter;
    bool output_valid;
    void* output_texture;
};

struct WorldTextureUpload {
    std::uint64_t key;
    std::int32_t x;
    std::int32_t y;
    std::int32_t word_width;
    std::int32_t height;
};

// A car paint is identified by both its indexed bitmap upload and the exact
// 64x4 palette-bank upload containing the primitive's 16-word CLUT.
constexpr bool world_texture_upload_contains_clut(
    const WorldTextureUpload& upload,
    std::uint64_t expected_key,
    std::uint16_t clut
) noexcept {
    const std::int64_t clut_x = static_cast<std::int64_t>(clut & 63U) * 16;
    const std::int64_t clut_y = (clut >> 6U) & 511U;
    return
        upload.key == expected_key &&
        upload.word_width > 0 && upload.height > 0 &&
        clut_x >= upload.x && clut_y >= upload.y &&
        clut_x + 16 <= static_cast<std::int64_t>(upload.x) + upload.word_width &&
        clut_y + 1 <= static_cast<std::int64_t>(upload.y) + upload.height;
}

enum class WorldGpuRenderResult {
    success,
    invalid_argument,
    unsupported_platform,
    device_failed,
    shader_failed,
    resource_failed,
    render_failed,
};

enum class WorldGpuReadbackResult {
    success,
    not_ready,
    invalid_argument,
    device_failed,
    read_failed,
};

WorldGpuRenderResult render_world_d3d11(
    const WorldDrawList& draw_list,
    const std::uint16_t* vram,
    std::size_t vram_word_count,
    std::uint8_t* output_rgba,
    std::size_t output_size,
    WorldGpuRenderOptions options,
    WorldGpuRenderStats* stats
) noexcept;

WorldGpuReadbackResult try_read_world_d3d11_pair(
    bool use_software_adapter,
    std::uint8_t* first_output_rgba,
    std::uint8_t* second_output_rgba,
    std::size_t output_size,
    bool wait_for_completion = false
) noexcept;

WorldGpuReadbackResult try_read_world_d3d11_image(
    bool use_software_adapter,
    std::uint8_t* output_rgba,
    std::size_t output_size,
    bool wait_for_completion = false
) noexcept;

std::size_t pending_world_d3d11_readback_pairs(
    bool use_software_adapter
) noexcept;

// Begins a new temporal stream. All mutable resources from the prior stream are
// detached so an unfinished GPU tail cannot be mistaken for new readback work.
void reset_world_d3d11_readback(bool use_software_adapter) noexcept;

// Complete direct-output command lists before their shared presentation
// device and renderer worker are destroyed.
void drain_world_d3d11_direct_output() noexcept;

// Must be called from the renderer thread before its first render. Passing a
// non-null D3D11 device switches that thread to deferred command recording on
// the host's presentation device.
bool set_world_d3d11_presentation_device(void* d3d11_device) noexcept;

bool set_world_d3d11_texture_uploads(
    bool use_software_adapter,
    const WorldTextureUpload* uploads,
    std::size_t upload_count) noexcept;

const char* world_gpu_render_result_name(
    WorldGpuRenderResult result
) noexcept;

} // namespace opengt::render
